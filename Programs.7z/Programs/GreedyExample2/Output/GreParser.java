// $ANTLR 3.4 F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g 2013-03-05 23:09:01

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked"})
public class GreParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ID", "WS", "'#'", "'*/'", "'/*'"
    };

    public static final int EOF=-1;
    public static final int T__6=6;
    public static final int T__7=7;
    public static final int T__8=8;
    public static final int ID=4;
    public static final int WS=5;

    // delegates
    public Parser[] getDelegates() {
        return new Parser[] {};
    }

    // delegators


    public GreParser(TokenStream input) {
        this(input, new RecognizerSharedState());
    }
    public GreParser(TokenStream input, RecognizerSharedState state) {
        super(input, state);
    }

    public String[] getTokenNames() { return GreParser.tokenNames; }
    public String getGrammarFileName() { return "F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g"; }


    String s;



    // $ANTLR start "r"
    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:10:1: r : ID '#' ;
    public final void r() throws RecognitionException {
        Token ID1=null;

        try {
            // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:10:3: ( ID '#' )
            // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:10:5: ID '#'
            {
            ID1=(Token)match(input,ID,FOLLOW_ID_in_r25); 

            match(input,6,FOLLOW_6_in_r27); 

            s = (ID1!=null?ID1.getText():null); System.out.println("found "+s);

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "r"



    // $ANTLR start "mL_COMMENT"
    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:14:1: mL_COMMENT : '/*' ( options {greedy=false; } : . )* '*/' ;
    public final void mL_COMMENT() throws RecognitionException {
        try {
            // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:15:2: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:15:4: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match(input,8,FOLLOW_8_in_mL_COMMENT50); 

            // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:15:9: ( options {greedy=false; } : . )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==7) ) {
                    int LA1_1 = input.LA(2);

                    if ( (LA1_1==EOF) ) {
                        alt1=2;
                    }
                    else if ( ((LA1_1 >= ID && LA1_1 <= 8)) ) {
                        alt1=1;
                    }


                }
                else if ( ((LA1_0 >= ID && LA1_0 <= 6)||LA1_0==8) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:15:37: .
            	    {
            	    matchAny(input); 

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            match(input,7,FOLLOW_7_in_mL_COMMENT68); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "mL_COMMENT"



    // $ANTLR start "mL_COMMENT1"
    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:16:1: mL_COMMENT1 : '/*' ( . )* '*/' ;
    public final void mL_COMMENT1() throws RecognitionException {
        try {
            // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:17:2: ( '/*' ( . )* '*/' )
            // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:17:4: '/*' ( . )* '*/'
            {
            match(input,8,FOLLOW_8_in_mL_COMMENT177); 

            // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:17:9: ( . )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==7) ) {
                    alt2=2;
                }
                else if ( ((LA2_0 >= ID && LA2_0 <= 6)||LA2_0==8) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\GreedyExample\\Gre.g:17:12: .
            	    {
            	    matchAny(input); 

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            match(input,7,FOLLOW_7_in_mL_COMMENT187); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return ;
    }
    // $ANTLR end "mL_COMMENT1"

    // Delegated rules


 

    public static final BitSet FOLLOW_ID_in_r25 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_6_in_r27 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_8_in_mL_COMMENT50 = new BitSet(new long[]{0x00000000000001F0L});
    public static final BitSet FOLLOW_7_in_mL_COMMENT68 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_8_in_mL_COMMENT177 = new BitSet(new long[]{0x00000000000001F0L});
    public static final BitSet FOLLOW_7_in_mL_COMMENT187 = new BitSet(new long[]{0x0000000000000002L});

}