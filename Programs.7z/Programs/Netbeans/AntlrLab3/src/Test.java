import java.io.File;
import java.io.*;
import org.antlr.runtime.*;
public class Test {
public static void main(String[] args) throws Exception {
	
// Test Grammar Acts
//	ANTLRInputStream input = new ANTLRInputStream(System.in);
//        ANTLRStringStream input = new ANTLRStringStream("b #");
//	ActsLexer lexer = new ActsLexer(input);
//	CommonTokenStream tokens = new CommonTokenStream(lexer);
//	ActsParser parser = new ActsParser(tokens);
//	int n = parser.r();
//	System.out.println("n from NetBeans is : "+n);


//Test Grammar RuleArgsRets
//	ANTLRInputStream input = new ANTLRInputStream(System.in);
//        ANTLRStringStream input = new ANTLRStringStream("a #"); // For rule r
//        ANTLRStringStream input = new ANTLRStringStream("a # b #"); // For rule s
//	RuleArgsRetsLexer lexer = new RuleArgsRetsLexer(input);
//	CommonTokenStream tokens = new CommonTokenStream(lexer);
//	RuleArgsRetsParser parser = new RuleArgsRetsParser(tokens);
//	RuleArgsRetsParser.r_return n = parser.r(2,"my NetBeans string");
//	System.out.println("from NetBeans r_return.c: "+n.c+" and r_return.d: "+n.d);
//	System.out.println("Calling rule s in NetBeans: ");
//	parser.s();


//Test Grammar RuleExceps
//	ANTLRInputStream input = new ANTLRInputStream(System.in);
//        ANTLRStringStream input = new ANTLRStringStream("a #"); // For rule r
//	RuleExcepsLexer lexer = new RuleExcepsLexer(input);
//	CommonTokenStream tokens = new CommonTokenStream(lexer);
//	RuleExcepsParser parser = new RuleExcepsParser(tokens);
//	parser.r();
	

}
}