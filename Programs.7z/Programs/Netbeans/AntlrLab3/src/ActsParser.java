// $ANTLR 3.4 F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\ActionsEmbeddedExample\\Acts.g 2013-03-05 23:11:03

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked"})
public class ActsParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ID", "WS", "'#'", "'a'", "'b'", "'c'", "'d'"
    };

    public static final int EOF=-1;
    public static final int T__6=6;
    public static final int T__7=7;
    public static final int T__8=8;
    public static final int T__9=9;
    public static final int T__10=10;
    public static final int ID=4;
    public static final int WS=5;

    // delegates
    public Parser[] getDelegates() {
        return new Parser[] {};
    }

    // delegators


    public ActsParser(TokenStream input) {
        this(input, new RecognizerSharedState());
    }
    public ActsParser(TokenStream input, RecognizerSharedState state) {
        super(input, state);
    }

    public String[] getTokenNames() { return ActsParser.tokenNames; }
    public String getGrammarFileName() { return "F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\ActionsEmbeddedExample\\Acts.g"; }


    String s;



    // $ANTLR start "r"
    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\ActionsEmbeddedExample\\Acts.g:12:1: r returns [int n] : ( 'a' '#' | 'b' '#' | 'c' '#' | 'd' '#' );
    public final int r() throws RecognitionException {
        int n = 0;



        n =0; // init return value

        try {
            // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\ActionsEmbeddedExample\\Acts.g:19:3: ( 'a' '#' | 'b' '#' | 'c' '#' | 'd' '#' )
            int alt1=4;
            switch ( input.LA(1) ) {
            case 7:
                {
                alt1=1;
                }
                break;
            case 8:
                {
                alt1=2;
                }
                break;
            case 9:
                {
                alt1=3;
                }
                break;
            case 10:
                {
                alt1=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;

            }

            switch (alt1) {
                case 1 :
                    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\ActionsEmbeddedExample\\Acts.g:19:3: 'a' '#'
                    {
                    match(input,7,FOLLOW_7_in_r41); 

                    match(input,6,FOLLOW_6_in_r43); 

                    n =23;

                    }
                    break;
                case 2 :
                    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\ActionsEmbeddedExample\\Acts.g:20:2: 'b' '#'
                    {
                    match(input,8,FOLLOW_8_in_r48); 

                    match(input,6,FOLLOW_6_in_r50); 

                    n =9;

                    }
                    break;
                case 3 :
                    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\ActionsEmbeddedExample\\Acts.g:21:2: 'c' '#'
                    {
                    match(input,9,FOLLOW_9_in_r55); 

                    match(input,6,FOLLOW_6_in_r57); 

                    n =1;

                    }
                    break;
                case 4 :
                    // F:\\Faculty\\Compiler Design CS407\\Labs\\Labs- Dr Rasha\\Lab3\\Programs\\ActionsEmbeddedExample\\Acts.g:22:2: 'd' '#'
                    {
                    match(input,10,FOLLOW_10_in_r62); 

                    match(input,6,FOLLOW_6_in_r64); 

                    }
                    break;

            }

            System.out.println("returning value n="+n);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }

        finally {
        	// do for sure before leaving
        }
        return n;
    }
    // $ANTLR end "r"

    // Delegated rules


 

    public static final BitSet FOLLOW_7_in_r41 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_6_in_r43 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_8_in_r48 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_6_in_r50 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_9_in_r55 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_6_in_r57 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_10_in_r62 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_6_in_r64 = new BitSet(new long[]{0x0000000000000002L});

}